<?php
// Include core.php for session checking
include '../settings/core.php';

// Check if user is logged in, if not, redirect to login page
if (!is_logged_in()) {
    header("Location: ../Login/login.php");
    exit();
}
?>
<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Chore Control</title>
    <link rel="stylesheet" href="../Css/addchore.css">
</head>

<body>
    <ul class="homelogo">
        <li><a href="../view/homepage.php">Home</a></li>
    </ul>
    
    <div class="container">
        <h2>Chore Control</h2>
        <!-- PHP code to display chores from the database -->
        <?php
        // Include connection.php for database connection
        include '../settings/connection.php';

        // Fetch all chores from the database
        $sql = "SELECT * FROM Chores";
        $result = mysqli_query($conn, $sql);

        // Check if there are any chores
        if (mysqli_num_rows($result) > 0) {
            // Display the chores in a table
            echo "<table>";
            echo "<thead><tr><th>Chore Name</th><th>Actions</th></tr></thead>";
            echo "<tbody>";
            while ($row = mysqli_fetch_assoc($result)) {
                echo "<tr>";
                echo "<td>" . $row['chorename'] . "</td>";
                echo "<td>";
                // Edit button with action PHP link
                echo "<a href='../action/edit_a_chore_action.php?cid=" . $row['cid'] . "'><button>Edit</button></a>";
                // Delete button with action PHP link
                echo "<a href='../action/delete_chore_action.php?cid=" . $row['cid'] . "'><button>Delete</button></a>";
                echo "</td>";
                echo "</tr>";
            }
            echo "</tbody>";
            echo "</table>";
        } else {
            echo "<p>No chores found.</p>";
        }
        ?>
    </div>
</body>

</html>
