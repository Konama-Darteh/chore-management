const form = document.getElementById('registrationForm');
const firstName = document.getElementById('firstName');
const lastName = document.getElementById('lastName');
const gender = document.querySelector('input[name="gender"]:checked');
const familyRole = document.getElementById('familyRole');
const dob = document.getElementById('dob');
const phoneNumber = document.getElementById('phoneNumber');
const email = document.getElementById('email');
const password = document.getElementById('password');
const passwordRetype = document.getElementById('passwordRetype');

form.addEventListener('submit', (e) => {
    e.preventDefault();

    validateInputs();
});

const setError = (element, message) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.classList.remove('success');
};

const setSuccess = (element) => {
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.innerText = '';
    inputControl.classList.add('success');
    inputControl.classList.remove('error');

    
};
const isValidFname = firstName =>{
    const re = /^[a-zA-Z]+$/;
    return re.test(String(first).toLowerCase());
};

const isValidLname = lastName =>{
    const re = /^[a-zA-Z]+$/;
    return re.test(String(last).toLowerCase());
};


const isValidEmail = email =>{
    const re = /^[a-zA-Z0-9.!#$%&'*+/=?^_`{|}~-]+@[a-zA-Z0-9-]+(?:\.[a-zA-Z0-9-]+)*$/;
    return re.test(String(email).toLowerCase());
};

const isValidPhoneNumber = phoneNumber => {
    
    const re = /^\(?(\d{3})\)?[- ]?(\d{3})[- ]?(\d{4})$/;
    return re.test(phoneNumber);
};

const isValidPassword = password => {
    const re = /^(?=.*[a-z])(?=.*[A-Z])(?=.*[0-9])(?=.*[.!#$_@])[a-zA-Z0-9.!#$_@]{8,}$/;
    return re.test(password)
};


const validateInputs = () => {
    const firstNameValue = firstName.value.trim();
    const lastNameValue = lastName.value.trim();
    const genderValue = gender ? gender.value : null;
    const familyRoleValue = familyRole.value;
    const dobValue = dob.value.trim();
    const phoneNumberValue = phoneNumber.value.trim();
    const emailValue = email.value.trim();
    const passwordValue = password.value.trim();
    const passwordRetypeValue = passwordRetype.value.trim();

    if (firstNameValue === '') {
        setError(firstName, 'First Name is required');
    } else {
        setSuccess(firstName);
    }

    if (lastNameValue === '') {
        setError(lastName, 'Last Name is required');
    } else {
        setSuccess(lastName);
    }

    if (!genderValue) {
        setError(document.querySelector('.info'), 'Gender is required');
    } else {
        setSuccess(document.querySelector('.info'));
    }

    if (familyRoleValue === '0') {
        setError(familyRole, 'Family Role is required');
    } else {
        setSuccess(familyRole);
    }

    if (dobValue === '') {
        setError(dob, 'Date of Birth is required');
    } else {
        setSuccess(dob);
    }

    if (phoneNumberValue === '') {
        setError(phoneNumber, 'Phone number is required');
    } else if (!isValidPhoneNumber(phoneNumberValue)) {
        setError(phoneNumber, 'Provide a valid phone number');
    } else {
        setSuccess(phoneNumber);
    }

    if (emailValue === '') {
        setError(email, 'Email is required');
    } else if (!isValidEmail(emailValue)) {
        setError(email, 'Provide a valid email address');
    } else {
        setSuccess(email);
    }

    if (passwordRetypeValue === '') {
        setError(passwordRetype, 'Please confirm your password');
    } else if (!isValidPassword(passwordRetypeValue)) {
        setError(passwordRetype, 'Passwords must meet the specified criteria');
    } else if (passwordRetypeValue !== passwordValue) {
        setError(passwordRetype, "Passwords don't match");
    } else {
        setSuccess(passwordRetype);
    }
    
    
};
