const form = document.getElementById('login-form');
const username = document.getElementById('username');
const password = document.getElementById('password');

form.addEventListener('submit',e=>{
    e.preventDefault();

    validateInputs();
});

const setError = (element, message) =>{
    const inputControl = element.parentElemet;
    const errorDsplay = inputControl.querySelector('.error');

    errorDsplay.innerText = message;
    inputControl.classList.add('error');
    inputControl.clasList.remove('success');
}

const setSuccess = element =>{
    const inputControl = element.parentElement;
    const errorDisplay = inputControl.querySelector('.error');

    errorDisplay.inerText = '';
    inputControl.classList.add('success');
    inputControl.clasList.remove('error');
}
const validateInputs = () =>{
    const usernameValue = username.value.trim();
    const passwordValue = password.value.trim();

    if(usernameValue ===''){
        setError(username, 'Username is required');

    }
    else{
        setSuccess(username);
    }
    
    if(passwordValue ===''){
        setError(password, 'Pasword is required');

    }
    else if(passwordValue.length < 8){
         setError(password, 'Password must be at least 8 characters.');
    }

    

    
}